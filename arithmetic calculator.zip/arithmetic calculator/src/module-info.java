/**
 * 
 */
/**
 * 
 */
module arithmetic_calculator {
}