package arithmetic_calculator;
import java.util.Scanner;

class calci
{
	float n,m;
	public calci(float n,float m)
	{
		this.n=n;
		this.m=m;
	}
	public float addition() {return n+m;} //logic for addition
	public float subtraction() {return n-m;} //logic for subtraction
	public float multiplication() {return n*m;} //logic for multiplication
	public float division() // logic for division
		{
			if (m==0)
				{
					return Float.NaN; // if number is divided by zero its return not a number
				}
			return n/m;
		}
}

public class arithmetic_calculator {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		float n,m,ans;
		boolean b=true;
		while(b)
		{
			System.out.println("Enter the first number : ");
			n=sc.nextFloat();
			System.out.println("Enter the second number : ");
			m=sc.nextFloat();
			calci numbers=new calci(n,m);
			System.out.println("Select the operations to perform");
			System.out.println("+ For Addition.");
			System.out.println("- For Subtraction.");
			System.out.println("* For multiplication.");
			System.out.println("/ For Division.");
			System.out.println("E For end the task");
			char choice=sc.next().charAt(0);
			
			switch(choice)
				{
				case '+':
					System.out.println("Answers is " + numbers.addition());
					break;
					
				case '-':
					System.out.println("Answers is " + numbers.subtraction());
					break;
					
				case '*':
					System.out.println("Answers is " + numbers.multiplication());
					break;
					
				case '/':
					if (Float.isNaN(numbers.division()))
						System.out.println("Can't Divide by zero");
					System.out.println("Answers is " + numbers.division());
					break;
					
				case 'E': case 'e':
					b=false;
					System.out.println("task is end////");
					break;
					
				}
		 }
		
		

	}

}
